﻿#!/usr/bin/env python
"""Setup for zs_pluginmanager."""

import ast
from setuptools import setup

try:
    # for pip >= 10
    from pip._internal.req import parse_requirements
except ImportError:
    # for pip <= 9.0.3
    from pip.req import parse_requirements


def load_requirements(fname):
    try:
        reqs = parse_requirements(fname, session="autopep8_quotes")
        return [str(ir.req) for ir in reqs]
    except BaseException:
        reqs = parse_requirements(fname, session="autopep8_quotes")
        return [str(ir.requirement) for ir in reqs]


def version():
    """Return version string."""
    import os
    print(os.listdir())
    with open("zs_pluginmanager/__init__.py") as input_file:
        for line in input_file:
            if line.startswith("__version__"):
                return ast.parse(line).body[0].value.s
    return None


with open("README.md") as readme:
    setup(name="ZS-PluginManager",
          version=version(),
          description="Library to use plugins in Python programs. ",
          long_description=readme.read(),
          long_description_content_type="text/markdown",
          license="GNU Affero General Public License v3",
          author="Dmitrii",
          author_email="zoynels@gmailc.com",
          url="https://github.com/Zoynels/ZS-PluginManager",
          classifiers=["Intended Audience :: Developers",
                       "Environment :: Plugins",
                       "Programming Language :: Python :: 3",
                       "License :: OSI Approved :: GNU Affero General Public License v3"],
          keywords="plugin, plug-in, manager",
          entry_points={},
          packages=["zs_pluginmanager"],
          package_dir={"zs_pluginmanager": "zs_pluginmanager"},
          package_data={"zs_pluginmanager": ["py.typed"]},
          include_package_data=True,
          install_requires=load_requirements("requirements.txt"),
          extras_require={})
