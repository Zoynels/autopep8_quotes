﻿# flake8: noqa
__version__ = "0.0.1"


from .manager import PluginManager
from .plugin import Plugin
